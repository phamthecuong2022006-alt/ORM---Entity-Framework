using BookManagementMVC.Models;
using Microsoft.EntityFrameworkCore;

namespace BookManagementMVC.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<Book> Books => Set<Book>();
}
