using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookManagementMVC.Models;

public class Book
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập tên sách")]
    [StringLength(200)]
    [Display(Name = "Tên sách")]
    public string Title { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập tác giả")]
    [StringLength(150)]
    [Display(Name = "Tác giả")]
    public string Author { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập thể loại")]
    [StringLength(100)]
    [Display(Name = "Thể loại")]
    public string Category { get; set; } = string.Empty;

    [Range(0, 100000000, ErrorMessage = "Giá phải từ 0 đến 100.000.000")]
    [Column(TypeName = "decimal(18,2)")]
    [Display(Name = "Giá")]
    public decimal Price { get; set; }

    [Range(1000, 2100, ErrorMessage = "Năm xuất bản không hợp lệ")]
    [Display(Name = "Năm xuất bản")]
    public int PublishedYear { get; set; }
}
